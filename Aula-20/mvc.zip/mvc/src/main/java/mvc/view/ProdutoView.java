package mvc.view;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import mvc.controle.ProdutoControle;
import mvc.modelo.Produto;

public class ProdutoView extends JFrame {

    // Instância do Controle (Respeitando o MVC)
    private final ProdutoControle controle = new ProdutoControle();

    // Componentes da interface
    private JTextField txtId;
    private JTextField txtNome;
    private JTextField txtMarca;
    private JTextField txtVoltagem;
    private JTextField txtPreco;

    private JButton btnCadastrar;
    private JButton btnBuscar;
    private JButton btnAlterar;
    private JButton btnExcluir;
    private JButton btnListar;
    private JButton btnLimpar;

    private JTable tabela;
    private DefaultTableModel modeloTabela;

    public ProdutoView() {
        setTitle("Gerenciamento de Produtos - MVC");
        setSize(850, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        criarInterface();
        configurarEventos();
        atualizarTabela();
    }

    private void criarInterface() {
        // Título
        JLabel titulo = new JLabel("GERENCIAMENTO DE PRODUTOS", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(30, 60, 100));
        titulo.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        add(titulo, BorderLayout.NORTH);

        // Painel principal
        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));
        painelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 15));
        add(painelPrincipal, BorderLayout.CENTER);

        // Painel de cadastro
        JPanel painelCadastro = new JPanel(new GridBagLayout());
        painelCadastro.setBorder(BorderFactory.createTitledBorder("Dados do Produto"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        // ID
        gbc.gridx = 0; gbc.gridy = 0;
        painelCadastro.add(new JLabel("ID:"), gbc);
        txtId = new JTextField(15);
        gbc.gridx = 1;
        painelCadastro.add(txtId, gbc);

        // Nome
        gbc.gridx = 0; gbc.gridy = 1;
        painelCadastro.add(new JLabel("Nome:"), gbc);
        txtNome = new JTextField(25);
        gbc.gridx = 1;
        painelCadastro.add(txtNome, gbc);

        // Marca
        gbc.gridx = 0; gbc.gridy = 2;
        painelCadastro.add(new JLabel("Marca:"), gbc);
        txtMarca = new JTextField(25);
        gbc.gridx = 1;
        painelCadastro.add(txtMarca, gbc);

        // Voltagem
        gbc.gridx = 0; gbc.gridy = 3;
        painelCadastro.add(new JLabel("Voltagem (110v/220v):"), gbc);
        txtVoltagem = new JTextField(15);
        gbc.gridx = 1;
        painelCadastro.add(txtVoltagem, gbc);

        // Preço
        gbc.gridx = 0; gbc.gridy = 4;
        painelCadastro.add(new JLabel("Preço (R$):"), gbc);
        txtPreco = new JTextField(15);
        gbc.gridx = 1;
        painelCadastro.add(txtPreco, gbc);

        painelPrincipal.add(painelCadastro, BorderLayout.NORTH);

        // Tabela de produtos
        modeloTabela = new DefaultTableModel(
                new Object[]{"ID", "Nome", "Marca", "Voltagem", "Preço"}, 0
        ) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false; 
            }
        };

        tabela = new JTable(modeloTabela);
        tabela.setRowHeight(25);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getTableHeader().setReorderingAllowed(false);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(BorderFactory.createTitledBorder("Produtos Cadastrados"));
        painelPrincipal.add(scroll, BorderLayout.CENTER);

        // Painel de botões
        JPanel painelBotoes = new JPanel(new FlowLayout());
        btnCadastrar = new JButton("Cadastrar");
        btnBuscar = new JButton("Buscar");
        btnAlterar = new JButton("Alterar");
        btnExcluir = new JButton("Excluir");
        btnListar = new JButton("Listar");
        btnLimpar = new JButton("Limpar");

        painelBotoes.add(btnCadastrar);
        painelBotoes.add(btnBuscar);
        painelBotoes.add(btnAlterar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnListar);
        painelBotoes.add(btnLimpar);

        painelPrincipal.add(painelBotoes, BorderLayout.SOUTH);
    }

    private void configurarEventos() {
        btnCadastrar.addActionListener(e -> cadastrar());
        btnBuscar.addActionListener(e -> buscar());
        btnAlterar.addActionListener(e -> alterar());
        btnExcluir.addActionListener(e -> excluir());
        btnListar.addActionListener(e -> atualizarTabela());
        btnLimpar.addActionListener(e -> limparCampos());

        // Preenche campos ao clicar na tabela
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabela.getSelectedRow() != -1) {
                int linha = tabela.convertRowIndexToModel(tabela.getSelectedRow());
                txtId.setText(modeloTabela.getValueAt(linha, 0).toString());
                txtNome.setText(modeloTabela.getValueAt(linha, 1).toString());
                txtMarca.setText(modeloTabela.getValueAt(linha, 2).toString());
                txtVoltagem.setText(modeloTabela.getValueAt(linha, 3).toString());
                txtPreco.setText(modeloTabela.getValueAt(linha, 4).toString());
            }
        });
    }

    private void cadastrar() {
        try {
            String nome = lerTexto(txtNome, "Informe o nome!");
            String marca = lerTexto(txtMarca, "Informe a marca!");
            String voltagem = lerTexto(txtVoltagem, "Informe a voltagem!");
            double preco = lerPreco();

            boolean sucesso = controle.cadastrar(nome, marca, voltagem, preco);
            
            if(sucesso) {
                mostrarMensagem("Produto cadastrado com sucesso!");
                atualizarTabela();
                limparCampos();
            } else {
                mostrarErro("Falha ao cadastrar no banco de dados.");
            }
        } catch (IllegalArgumentException ex) {
            mostrarErro(ex.getMessage());
        }
    }

    private void buscar() {
        try {
            int id = lerId();
            Produto produto = controle.buscar(id);

            if (produto != null) {
                txtNome.setText(produto.getNome());
                txtMarca.setText(produto.getMarca());
                txtVoltagem.setText(produto.getVoltagem());
                txtPreco.setText(String.valueOf(produto.getPreco()));
                mostrarMensagem("Produto encontrado!");
            } else {
                mostrarMensagem("Produto não encontrado!");
            }
        } catch (IllegalArgumentException ex) {
            mostrarErro(ex.getMessage());
        }
    }

    private void alterar() {
        try {
            int id = lerId();
            String nome = lerTexto(txtNome, "Informe o nome!");
            String marca = lerTexto(txtMarca, "Informe a marca!");
            String voltagem = lerTexto(txtVoltagem, "Informe a voltagem!");
            double preco = lerPreco();

            boolean alterado = controle.alterar(id, nome, marca, voltagem, preco);

            if (alterado) {
                mostrarMensagem("Produto alterado com sucesso!");
                atualizarTabela();
                limparCampos();
            } else {
                mostrarMensagem("Falha ao alterar ou produto não encontrado!");
            }
        } catch (IllegalArgumentException ex) {
            mostrarErro(ex.getMessage());
        }
    }

    private void excluir() {
        try {
            int id = lerId();
            Produto produto = controle.buscar(id);

            if (produto == null) {
                mostrarMensagem("Produto não encontrado!");
                return;
            }

            int opcao = JOptionPane.showConfirmDialog(
                    this, "Deseja realmente excluir?", "Confirmar Exclusão",
                    JOptionPane.YES_NO_OPTION
            );

            if (opcao == JOptionPane.YES_OPTION) {
                boolean removido = controle.remover(id);
                if (removido) {
                    mostrarMensagem("Produto excluído com sucesso!");
                    atualizarTabela();
                    limparCampos();
                }
            }
        } catch (IllegalArgumentException ex) {
            mostrarErro(ex.getMessage());
        }
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        ArrayList<Produto> lista = controle.listar();
        
        if (lista != null) {
            for (Produto p : lista) {
                modeloTabela.addRow(new Object[]{
                        p.getId(),
                        p.getNome(),
                        p.getMarca(),
                        p.getVoltagem(),
                        p.getPreco()
                });
            }
        }
    }

    private void limparCampos() {
        tabela.clearSelection();
        txtId.setText("");
        txtNome.setText("");
        txtMarca.setText("");
        txtVoltagem.setText("");
        txtPreco.setText("");
        txtId.requestFocusInWindow();
    }

    private int lerId() {
        try {
            int id = Integer.parseInt(txtId.getText().trim());
            if (id <= 0) throw new NumberFormatException();
            return id;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um ID numérico válido e positivo!");
        }
    }

    private double lerPreco() {
        try {
            double preco = Double.parseDouble(txtPreco.getText().trim().replace(",", "."));
            if (preco < 0) throw new NumberFormatException();
            return preco;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um preço numérico válido!");
        }
    }

    private String lerTexto(JTextField campo, String mensagemErro) {
        String texto = campo.getText().trim();
        if (texto.isEmpty()) throw new IllegalArgumentException(mensagemErro);
        return texto;
    }

    private void mostrarMensagem(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Informação", JOptionPane.INFORMATION_MESSAGE);
    }

    private void mostrarErro(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem, "Erro", JOptionPane.ERROR_MESSAGE);
    }
}