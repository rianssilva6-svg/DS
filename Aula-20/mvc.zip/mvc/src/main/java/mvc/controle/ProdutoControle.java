package mvc.controle;
import java.util.ArrayList;

import mvc.dao.ProdutoDao;
import mvc.modelo.Produto;

public class ProdutoControle {

    private ProdutoDao dao;

    public ProdutoControle(){
        dao = new ProdutoDao();
    }

    public boolean cadastrar(String nome, String marca, String voltagem, double preco){
        Produto produto = new Produto(0, nome, marca, voltagem, preco);
        return dao.cadastrar(produto);
    }
    public ArrayList<Produto> listar(){
        return dao.listar();
    }

    public Produto buscar(int id){
        return dao.buscar(id);
    }

    public boolean alterar(int id,String nome, String marca, String voltagem,double preco){
        return dao.alterar(id, nome, marca, voltagem,preco);
    }
    public  boolean remover(int id){
        return dao.remover(id);
    }

}
