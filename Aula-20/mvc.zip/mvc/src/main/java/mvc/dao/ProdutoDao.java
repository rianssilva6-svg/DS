package mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import mvc.conexao.Conexao;
import mvc.modelo.Produto;

public class ProdutoDao {
    
    public boolean cadastrar(Produto produto){
        String sql = "INSERT INTO eletrodomestico(nome, marca, voltagem, preco) VALUES(?,?,?,?)";

        try (Connection conexao = Conexao.conectar();
            PreparedStatement comando = conexao.prepareStatement(sql)){
            comando.setString(1, produto.getNome());
            comando.setString(2, produto.getMarca());
            comando.setString(3, produto.getVoltagem());
            comando.setDouble(4, produto.getPreco());
            
            comando.executeUpdate();
            return true;
        } catch(SQLException e){
            System.out.println("Erro ao cadastrar: " + e.getMessage());
            return false;
        }
    }


    public ArrayList<Produto> listar(){
        ArrayList<Produto> produtos = new ArrayList<>();
        String sql = "SELECT * FROM eletrodomestico ORDER BY id";
        
        try(Connection conexao = Conexao.conectar();
            PreparedStatement comando = conexao.prepareStatement(sql);
            ResultSet resultado = comando.executeQuery()){
            
            while (resultado.next()) {
                Produto produto = new Produto();
                produto.setId(resultado.getInt("id"));
                produto.setNome(resultado.getString("nome"));
                produto.setMarca(resultado.getString("marca"));
                produto.setVoltagem(resultado.getString("voltagem"));
                produto.setPreco(resultado.getDouble("preco"));
                produtos.add(produto);
            }
        } catch(SQLException e){
            System.out.println("Erro ao listar: " + e.getMessage());
        }
        return produtos;
    }

    public Produto buscar(int id){
        String sql = "SELECT * FROM eletrodomestico WHERE id = ?";

        try(Connection conexao = Conexao.conectar();
            PreparedStatement comando = conexao.prepareStatement(sql)){
            comando.setInt(1, id);
            try(ResultSet resultado = comando.executeQuery()){
                if (resultado.next()) {
                    return new Produto(
                        resultado.getInt("id"),
                        resultado.getString("nome"),
                        resultado.getString("marca"),
                        resultado.getString("voltagem"),
                        resultado.getDouble("preco")
                    );
                }
            }
        } catch(SQLException e){
            System.out.println("Erro ao buscar: " + e.getMessage());
        }
        return null;
    }

    public boolean alterar(int id, String nome, String marca, String voltagem, double preco){
        String sql = "UPDATE eletrodomestico SET nome=?, marca=?, voltagem=?, preco=? WHERE id=?";

        try(Connection conexao = Conexao.conectar();
            PreparedStatement comando = conexao.prepareStatement(sql)){
            comando.setString(1, nome);
            comando.setString(2, marca);
            comando.setString(3, voltagem);
            comando.setDouble(4, preco);
            comando.setInt(5, id);
            return comando.executeUpdate() > 0;
        } catch(SQLException e){
            System.out.println("Erro ao alterar: " + e.getMessage());
            return false;
        }
    }

    public boolean remover(int id){
        String sql = "DELETE FROM eletrodomestico WHERE id=?";

        try(Connection conexao = Conexao.conectar();
            PreparedStatement comando = conexao.prepareStatement(sql)){
            comando.setInt(1, id);
            return comando.executeUpdate() > 0;
        } catch(SQLException e){
            System.out.println("Erro ao remover: " + e.getMessage());
            return false;
        }
    }
}